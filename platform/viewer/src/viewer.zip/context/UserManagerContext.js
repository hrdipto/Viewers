import React from 'react';

const UserManagerContext = React.createContext();

export default UserManagerContext;
