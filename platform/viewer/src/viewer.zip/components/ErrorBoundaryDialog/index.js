import ErrorBoundaryDialog from './ErrorBoundaryDialog';

export default ErrorBoundaryDialog;
