export { Svg } from './Svg.js';
export { SVGS } from './getSvg.js';
