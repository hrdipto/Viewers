import React from 'react';
const thLarge = <svg
  xmlns="http://www.w3.org/2000/svg"
  viewBox="0 0 15 13"
  aria-labelledby="title"
  width="1em"
  height="1em"
  stroke="none"
  fill="currentColor"
>
  <title id="title">TH Large</title>
  <path d="M0,0 7,0 7,6 0,6Z M8,0 15,0 15,6 8,6Z M0,7 7,7 7,13 0,13Z M8,7 15,7 15,13 8,13Z" />
</svg>
export default thLarge;