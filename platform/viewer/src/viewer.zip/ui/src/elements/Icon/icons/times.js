import React from 'react';
const times = <svg
  xmlns="http://www.w3.org/2000/svg"
  viewBox="0 0 14 14"
  aria-labelledby="title"
  width="1em"
  height="1em"
  stroke="currentColor"
  stroke-width="1.75"
>
  <title id="title">Times</title>
  <path d="M1,1 13,13 M1,13 13,1" />
</svg>
export default times;