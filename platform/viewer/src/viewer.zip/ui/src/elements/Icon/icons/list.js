import React from 'react';
const list = <svg
  xmlns="http://www.w3.org/2000/svg"
  viewBox="0 0 18 10"
  aria-labelledby="title"
  width="1em"
  height="1em"
  fill="currentColor"
>
  <title id="title">List</title>
  <path d="M0,0 2,0 2,2 0,2Z M4,0 18,0 18,2 4,2Z M0,4 2,4 2,6 0,6Z M4,4 18,4 18,6 4,6Z M0,8 2,8 2,10 0,10Z M4,8 18,8 18,10 4,10Z" />
</svg>
export default list;