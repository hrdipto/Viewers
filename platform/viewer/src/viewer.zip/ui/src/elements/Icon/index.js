import { ICONS } from './getIcon.js';
import Icon from './Icon.js';

export { Icon, ICONS };
