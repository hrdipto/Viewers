import React from 'react';
const bars = <svg
  xmlns="http://www.w3.org/2000/svg"
  viewBox="0 0 1792 1792"
  aria-labelledby="title"
  width="1em"
  height="1em"
  fill="currentColor"
>
  <title id="title">Bars</title>
  <path d="M1664 1344v128q0 26-19 45t-45 19h-1408q-26 0-45-19t-19-45v-128q0-26 19-45t45-19h1408q26 0 45 19t19 45zm0-512v128q0 26-19 45t-45 19h-1408q-26 0-45-19t-19-45v-128q0-26 19-45t45-19h1408q26 0 45 19t19 45zm0-512v128q0 26-19 45t-45 19h-1408q-26 0-45-19t-19-45v-128q0-26 19-45t45-19h1408q26 0 45 19t19 45z" />
</svg>
export default bars;