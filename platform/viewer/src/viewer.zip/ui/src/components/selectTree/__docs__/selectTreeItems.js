export default [
  {
    label: 'A',
    value: 'A',
    items: [
      {
        label: 'Abdominal Wall',
        value: 'AbdominalWall',
      },
      {
        label: 'Adrenal Left',
        value: 'AdrenalLeft',
      },
    ],
  },
  {
    label: 'B',
    value: 'B',
    items: [
      {
        label: 'Brain',
        value: 'Brain',
      },
      {
        label: 'Breast',
        value: 'Breast',
      },
    ],
  },
];
