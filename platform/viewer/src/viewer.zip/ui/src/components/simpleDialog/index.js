export { SimpleDialog } from './SimpleDialog.js';
