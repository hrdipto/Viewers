export { QuickSwitch } from './QuickSwitch.js';
