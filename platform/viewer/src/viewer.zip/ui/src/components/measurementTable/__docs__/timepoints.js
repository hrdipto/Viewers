export default [
  {
    label: 'Follow-up 2',
    date: '20-Dec-18',
  },
  {
    label: 'Follow-up 1',
    date: '15-Jun-18',
  },
  {
    label: 'Baseline',
    date: '10-Apr-18',
  },
];
